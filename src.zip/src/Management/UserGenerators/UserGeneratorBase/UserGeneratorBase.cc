#include "UserGeneratorBase.h"

UserGeneratorBase::~UserGeneratorBase(){
}


void UserGeneratorBase::initialize(){

    // Init super-class
    CloudManagerBase::initialize();

    EV_INFO << "UserGeneratorBase::initialize - Init" << endl;

    // Init module parameters
    startDelay = par ("startDelay");
    intervalBetweenUsers = &par ("intervalBetweenUsers");
    allUsersArriveAtOnce = par ("allUsersArriveAtOnce");
    showUserInstances = par ("showUserInstances");

    // Gates
    fromCloudProviderGate = gate ("fromCloudProvider");
    toCloudProviderGate = gate ("toCloudProvider");


    EV_INFO << "UserGeneratorBase::initialize - Generating users before simulation" << endl;

    groupOfUsers.clear();
    userInstances.clear();

    nUserInstancesFinished = 0;
    nUserIndex=0;

    // Create user instances
    generateUsersBeforeSimulationStarts();

    // Show generated users instances
    if (showUserInstances){
        //EV_DEBUG << usersIstancesToString ();
    }

    EV_INFO << "UserGeneratorBase::initialize - Scheduling a message" << endl;

    // Start execution!
    cMessage *waitToExecuteMsg = new cMessage (Timer_WaitToExecute.c_str());
    scheduleAt (simTime().dbl()+startDelay, waitToExecuteMsg);

    EV_INFO << "UserGeneratorBase::initialize - End" << endl;
}


cGate* UserGeneratorBase::getOutGate (cMessage *msg){

    cGate* nextGate;

           // Init...
           nextGate = nullptr;

           // If msg arrives from cloud provider
           if (msg->getArrivalGate()==fromCloudProviderGate){
               nextGate = toCloudProviderGate;
           }

       return nextGate;
}


void UserGeneratorBase::generateUsersBeforeSimulationStarts (){

    std::vector<CloudUser*>::iterator userTypeIterator;
    std::vector <CloudUserInstance*> userInstancesLocal;
    unsigned int currentUserNumber, currentUserInstance;
    CloudUserInstance* newUser;
    CloudUserInstance* pUser;
    int  nSize;

    // Init...
    userTypeIterator = userTypes.begin();
    currentUserNumber = 0;

    // Process each user type to generate the user instances
    while((userTypeIterator != userTypes.end()))
    {

        // New vector of user instances
        userInstancesLocal.clear();

        // Generate the corresponding instances of the current user type
        for (currentUserInstance = 0; currentUserInstance<(*userTypeIterator)->getNumInstances(); currentUserInstance++){

            // Create a new user instance
            newUser = new CloudUserInstance (*userTypeIterator, currentUserNumber, currentUserInstance, (*userTypeIterator)->getNumInstances());

            // Insert current user instance into the corresponding vector
            userInstancesLocal.push_back(newUser);
            userHashMap[newUser->getUserID()]=newUser;

            //update user instance
            userInstances.push_back(newUser);
        }

        // Insert current user instances in the global users vector
        groupOfUsers.push_back(userInstancesLocal);

        // Process next user type
        userTypeIterator++;
        currentUserNumber++;
    }
}


string UserGeneratorBase::usersIstancesToString (){

    std::vector<std::vector <CloudUserInstance*>>::iterator globalIterator;
    std::vector <CloudUserInstance*>::iterator usersIterator;
    std::ostringstream info;


        // Main text
        info << std::endl << groupOfUsers.size() << " types of user instances in " << getFullPath() << endl << endl;

        // Init iterators
        globalIterator = groupOfUsers.begin();

        // For each entry in the users vector...
        while (globalIterator != groupOfUsers.end()){

            // Init iterator for the current user type
            usersIterator = (*globalIterator).begin();

            // Print user type
            info << "\tUser type:" << (*usersIterator)->getType() << "  -  #instances: " << (*globalIterator).size() << endl << endl;

            while (usersIterator != (*globalIterator).end()){

                info << "\t  + UserID: " << (*usersIterator)->toString(false, false) << endl;

                // Process next user instance
                usersIterator++;
            }

            // Process next user type
            globalIterator++;
        }

    return info.str();
}


