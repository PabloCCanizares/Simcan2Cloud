#include "CloudManagerBase.h"

CloudManagerBase::~CloudManagerBase(){

    vmTypes.clear();
    userTypes.clear();
    appTypes.clear();
}


void CloudManagerBase::initialize(){

    int result;

        // Init super-class
        cSIMCAN_Core::initialize();

        // Init module parameters
        showApps = par ("showApps");

        // Parse application list
        result = parseAppList();

        // Something goes wrong...
        if (result == SC_ERROR){
            error ("Error while parsing application list.");
        }
        else if (showApps){
            EV_DEBUG << appsToString ();
        }

        // Init module parameters
        showUsersVms = par ("showUsersVms");

        // Parse VMs list
        result = parseVmsList();

        // Something goes wrong...
        if (result == SC_ERROR){
         error ("Error while parsing VMs list");
        }
        else if (showUsersVms){
           EV_DEBUG << vmsToString ();
        }

        // Parse user list
        result = parseUsersList();

        // Something goes wrong...
        if (result == SC_ERROR){
           error ("Error while parsing users list");
        }
        else if (showUsersVms){
           EV_DEBUG << usersToString ();
        }
}


int CloudManagerBase::parseAppList (){

    int numApplications, currentApp, numParams, currentParam;
    int result;
    tNedType paramTypeNed;
    Application* currentAppObj;
    AppParameter* currentParameterObj;
    std::string instanceNameStr, instanceTypeStr, paramNameStr, paramTypeStr, paramUnitStr, paramValueStr;

        // Init...
        result = SC_OK;
        currentApp = currentParam = 0;

        // Get the string from the module
        const char *appListChr = par ("appList");
        cStringTokenizer tokenizer(appListChr);

        // First token, number of applications
        if (tokenizer.hasMoreTokens()){
            const char *numAppsChr = tokenizer.nextToken();
            numApplications = atoi(numAppsChr);
        }
        else{
            EV_ERROR << "Cannot read the first token (number of applications)" << endl;
            result = SC_ERROR;
        }

        // While there are unprocessed items...
        while ((tokenizer.hasMoreTokens()) && (currentApp < numApplications) && (result==SC_OK)){

            // Get the instance type
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
              const char *instanceTypeChr = tokenizer.nextToken();
              instanceTypeStr = instanceTypeChr;
            }
            else{
              EV_ERROR << "Cannot read instance type for application:" << currentApp << endl;
              result = SC_ERROR;
            }

            // Get the instance name
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *instanceNameChr = tokenizer.nextToken();
                instanceNameStr = instanceNameChr;
            }
            else{
                EV_ERROR << "Cannot read instance name for application:" << currentApp << endl;
                result = SC_ERROR;
            }

            // Get the number of parameters
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *numParamsChr = tokenizer.nextToken();
                numParams = atoi (numParamsChr);
            }
            else{
                EV_ERROR << "Cannot read number of parameters for application:" << currentApp << endl;
                result = SC_ERROR;
            }

                // Name, type and params have been read OK! Creating AppInstance object...
                if (result==SC_OK){

                    // New AppInstance
                    currentAppObj = new Application (instanceTypeStr, instanceNameStr);
                    currentParam = 0;

                    // Read app parameters...
                    while ((currentParam<numParams) && (result==SC_OK)){

                        // Get the parameter name
                        if (tokenizer.hasMoreTokens()){
                           const char *paramNameChr = tokenizer.nextToken();
                           paramNameStr = paramNameChr;
                        }
                        else{
                           EV_ERROR << "Cannot read parameter name[" << currentParam << "] for application:" << currentApp << endl;
                           result = SC_ERROR;
                        }

                        // Get the parameter type
                        if (tokenizer.hasMoreTokens()){
                            const char *paramTypeChr = tokenizer.nextToken();
                            paramTypeStr = paramTypeChr;

                            if (paramTypeStr.compare("int") == 0)
                                paramTypeNed = NedInt;
                            else if (paramTypeStr.compare("double") == 0)
                                paramTypeNed = NedDouble;
                            else if (paramTypeStr.compare("bool") == 0)
                                paramTypeNed = NedBool;
                            else if (paramTypeStr.compare("string") == 0)
                                paramTypeNed = NedString;
                            else{
                                EV_ERROR << "Unknown parameter type[" << currentParam << "] for application:" << currentApp << endl;
                                result = SC_ERROR;
                            }
                        }
                        else{
                            EV_ERROR << "Cannot read parameter type[" << currentParam << "] for application:" << currentApp << endl;
                            result = SC_ERROR;
                        }


                        // Get the parameter unit
                        if (tokenizer.hasMoreTokens()){
                            const char *paramUnitChr = tokenizer.nextToken();
                            paramUnitStr = paramUnitChr;
                        }
                        else{
                            EV_ERROR << "Cannot read parameter unit[" << currentParam << "] for application:" << currentApp << endl;
                            result = SC_ERROR;
                        }

                        // Get the parameter value
                        if (tokenizer.hasMoreTokens()){
                            const char *paramValueChr = tokenizer.nextToken();
                            paramValueStr = paramValueChr;
                        }
                        else{
                            EV_ERROR << "Cannot read parameter value[" << currentParam << "] for application:" << currentApp << endl;
                            result = SC_ERROR;
                        }

                        // Create a parameter object
                        currentParameterObj = new AppParameter(paramNameStr, paramTypeNed, paramUnitStr, paramValueStr);

                        // Set values...
                        currentAppObj->insertParameter(currentParameterObj);

                        // Process next parameter
                        currentParam++;
                    }

                    // Insert current app in the vector
                    appTypes.push_back(currentAppObj);
                }
        }

   return result;
}


int CloudManagerBase::parseVmsList (){

    int numVMs, currentVm, numCores, result;
    double cost, scu, diskGB, memoryGB;
    VirtualMachine* currentVmObj;
    std::string instanceTypeStr;

        // Init...
        result = SC_OK;
        currentVm = 0;

        // Get the string from the module
        const char *vmListChr = par ("vmList");
        cStringTokenizer tokenizer(vmListChr);

        // First token, number of VMs
        if (tokenizer.hasMoreTokens()){
            const char *numVMsChr = tokenizer.nextToken();
            numVMs = atoi(numVMsChr);
        }
        else{
            EV_ERROR << "Cannot read the first token (number of VMs)" << endl;
            result = SC_ERROR;
        }

        // While there are unprocessed items...
        while ((tokenizer.hasMoreTokens()) && (currentVm < numVMs) && (result==SC_OK)){

            // Get the VM type
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
              const char *vmTypeChr = tokenizer.nextToken();
              instanceTypeStr = vmTypeChr;
            }
            else{
              EV_ERROR << "Cannot read the type of VM:" << currentVm << endl;
              result = SC_ERROR;
            }


            // Get the Cost
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *costChr = tokenizer.nextToken();
                cost = atof(costChr);
            }
            else{
                EV_ERROR << "Cannot read the cost of VM:" << currentVm << endl;
                result = SC_ERROR;
            }

            // Get the number of cores
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *numCoresChr = tokenizer.nextToken();
                numCores = atoi (numCoresChr);
            }
            else{
                EV_ERROR << "Cannot read the number of cores of VM:" << currentVm << endl;
                result = SC_ERROR;
            }

            // Get the SCU
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *scuChr = tokenizer.nextToken();
                scu = atof (scuChr);
            }
            else{
                EV_ERROR << "Cannot read the SCU of VM:" << currentVm << endl;
                result = SC_ERROR;
            }

            // Get the DiskGB
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *diskChr = tokenizer.nextToken();
                diskGB = atof (diskChr);
            }
            else{
                EV_ERROR << "Cannot read the amount of disk space of VM:" << currentVm << endl;
                result = SC_ERROR;
            }

            // Get the memoryGB
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
               const char *memChr = tokenizer.nextToken();
               memoryGB = atof (memChr);
            }
            else{
               EV_ERROR << "Cannot read the amount of memory space of VM:" << currentVm << endl;
               result = SC_ERROR;
            }

            // Create current VM instance
            currentVmObj = new VirtualMachine (instanceTypeStr, cost, numCores, scu, diskGB, memoryGB);

            // Insert current VM in the vector
            vmTypes.push_back(currentVmObj);

            // Process next VM
            currentVm++;
        }


   return result;
}


int CloudManagerBase::parseUsersList (){

    int numUsers, currentUser, numUserInstances;
    int numApps, currentApp, numAppInstances;
    int numVMs, currentVM, numVmInstances, nRentTime;
    int result;
    Application* appPtr;
    VirtualMachine* vmPtr;
    CloudUser* currentUserObject;
    std::string userTypeStr, appNameStr, vmNameStr;

        // Init...
        result = SC_OK;
        numUsers = currentUser = numUserInstances = 0;
        numApps = currentApp = numAppInstances = 0;
        numVMs = currentVM = numVmInstances = nRentTime = 0;

        // Get the string from the module
        const char *userListChr = par ("userList");
        cStringTokenizer tokenizer(userListChr);

        // First token, number of users
        if (tokenizer.hasMoreTokens()){
            const char *numUsersChr = tokenizer.nextToken();
            numUsers = atoi(numUsersChr);
        }
        else{
            EV_ERROR << "Cannot read the first token (number of users)" << endl;
            result = SC_ERROR;
        }


        // For each user in the list...
        while ((tokenizer.hasMoreTokens()) && (currentUser < numUsers) && (result==SC_OK)){

            // Get the user type
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *userTypeChr = tokenizer.nextToken();
                userTypeStr = userTypeChr;
            }
            else{
                EV_ERROR << "Cannot read the user name for user:" << currentUser << endl;
                result = SC_ERROR;
            }

            // Get the number of user instances
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
               const char *numUserInstancesChr = tokenizer.nextToken();
               numUserInstances = atoi(numUserInstancesChr);
            }
            else{
               EV_ERROR << "Cannot read the number of user instances for user:" << userTypeStr << endl;
               result = SC_ERROR;
            }

            // Get the number of apps for the current user
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                const char *numAppsChr = tokenizer.nextToken();
                numApps = atoi(numAppsChr);
            }
            else{
                EV_ERROR << "Cannot read the number of applications for user:" << userTypeStr << endl;
                result = SC_ERROR;
            }


                // Parsing applications for current user...
                if (result == SC_OK){

                    // Init...
                    currentApp = 0;

                    // Create current user instance
                    currentUserObject = new CloudUser(userTypeStr, numUserInstances);

                    // Include each application
                    while ((currentApp<numApps) && (result==SC_OK)){

                        // Get the app name
                        if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                            const char *appNameChr = tokenizer.nextToken();
                            appNameStr = appNameChr;
                        }
                        else{
                            EV_ERROR << "Cannot read the app name[" << currentApp << "] for user:" << userTypeStr << endl;
                            result = SC_ERROR;
                        }

                        // Get the number of app instances
                        if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                            const char *numAppInstancesChr = tokenizer.nextToken();
                            numAppInstances = atoi(numAppInstancesChr);
                        }
                        else{
                            EV_ERROR << "Cannot read the number of instances for app [" << currentApp << "] in user:" << userTypeStr << endl;
                            result = SC_ERROR;
                        }

                        // Locate the AppInstance in the vector
                        appPtr = findApplication (appNameStr);

                            // App found!
                            if (appPtr != nullptr){
                                currentUserObject->insertApplication(appPtr, numAppInstances);
                            }
                            else{
                                EV_ERROR << "Application not found [" << appNameStr << "] in user:" << userTypeStr << endl;
                                result = SC_ERROR;
                            }

                        // Next app
                        currentApp++;
                    }
                }


                // Get the number of VMs for the current user
                if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                    const char *numVMsChr = tokenizer.nextToken();
                    numVMs = atoi(numVMsChr);
                }
                else{
                    EV_ERROR << "Cannot read the number of VMs for user:" << userTypeStr << endl;
                    result = SC_ERROR;
                }


                // Parsing VMs for current user...
                if (result == SC_OK){

                    // Init...
                    currentVM = 0;

                    // Include each VMs
                    while ((currentVM<numVMs) && (result==SC_OK)){

                        // Get the VM name
                        if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                            const char *vmNameChr = tokenizer.nextToken();
                            vmNameStr = vmNameChr;
                        }
                        else{
                            EV_ERROR << "Cannot read the VM name[" << currentVM << "] for user:" << userTypeStr << endl;
                            result = SC_ERROR;
                        }

                        // Get the number of VMs instances
                        if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                            const char *numVmInstancesChr = tokenizer.nextToken();
                            numVmInstances = atoi(numVmInstancesChr);
                        }
                        else{
                            EV_ERROR << "Cannot read the number of instances for VM [" << currentVM << "] in user:" << userTypeStr << endl;
                            result = SC_ERROR;
                        }

                        // Get the rental of VMs instances
                        if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
                            const char *nRentTimeChr = tokenizer.nextToken();
                            nRentTime = atoi(nRentTimeChr);
                        }
                        else{
                            EV_ERROR << "Cannot read the rental time of instances for VM [" << currentVM << "] in user:" << userTypeStr << endl;
                            result = SC_ERROR;
                        }

                        // Locate the VM in the vector
                        vmPtr = findVirtualMachine (vmNameStr);

                            // App found!
                            if (vmPtr != nullptr){
                                currentUserObject->insertVirtualMachine(vmPtr, numVmInstances, nRentTime);
                            }
                            else{
                                EV_ERROR << "Application not found [" << appNameStr << "] in user:" << userTypeStr << endl;
                                result = SC_ERROR;
                            }

                        // Next vm
                        currentVM++;
                    }
                }

               // Include user in the vector
                userTypes.push_back(currentUserObject);

                // Process next user
                currentUser++;
        }

    return result;
}


std::string CloudManagerBase::appsToString (){

    std::ostringstream info;
    int currentApp, currentParameter;

        // Main text for the applications of this manager
        info << std::endl << appTypes.size() << " applications parsed from ManagerBase in " << getFullPath() << endl << endl;

            // For each application
            for (currentApp=0; currentApp<appTypes.size(); currentApp++){

                info << "\tApplication[" << currentApp << "] --> " << appTypes.at(currentApp)->getAppName()  << ":" << appTypes.at(currentApp)->getType()
                     << " (" << appTypes.at(currentApp)->getNumParameters() << " parameters)" << endl;

                // For each parameter in the current application
                for (currentParameter = 0; currentParameter < appTypes.at(currentApp)->getNumParameters(); currentParameter++){
                    info << "\t   + " << appTypes.at(currentApp)->getParameter(currentParameter)->toString() << endl;
                }

                info << endl;
            }

    info << "---------------- End of parsed Applications in " << getFullPath() << " ----------------" << endl;

    return info.str();
}


std::string CloudManagerBase::vmsToString (){

    std::ostringstream info;
    int i;

        info.str("");

        // Main text for the VMs of this manager
        info << std::endl << vmTypes.size() << " VMs parsed from ManagerBase in " << getFullPath() << endl << endl;

        // For each VM...
        for (i=0; i<vmTypes.size(); i++){
            info << "\tVM[" << i << "]  --> " << vmTypes.at(i)->getType() << " : " << vmTypes.at(i)->featuresToString() << endl;
        }

        info << endl;
        info << "---------------- End of parsed VMs in " << getFullPath() << " ----------------" << endl;

    return info.str();
}


std::string CloudManagerBase::usersToString (){

    std::ostringstream info;
    int i;

        // Main text for the users of this manager
        info << std::endl << userTypes.size() << " CloudUsers parsed from ManagerBase in " << getFullPath() << endl << endl;

        for (i=0; i<userTypes.size(); i++){
            info << "\tUser[" << i << "]  --> " << userTypes.at(i)->toString() << endl;
        }

        info << "---------------- End of parsed CloudUsers in " << getFullPath() << " ----------------" << endl;

    return info.str();
}


Application* CloudManagerBase::findApplication (std::string appName){

    std::vector<Application*>::iterator it;
    Application* result;
    bool found;

        // Init
        found = false;
        result = nullptr;
        it = appTypes.begin();

        // Search...
        while((!found) && (it != appTypes.end())){

            if ((*it)->getAppName() == appName){
                found = true;
                result = *it;
            }
            else
                it++;
        }

    return result;
}


VirtualMachine* CloudManagerBase::findVirtualMachine (std::string vmType){

    std::vector<VirtualMachine*>::iterator it;
    VirtualMachine* result;
    bool found;

        // Init
        found = false;
        result = nullptr;
        it = vmTypes.begin();

        // Search...
        while((!found) && (it != vmTypes.end())){

            if ((*it)->getType() == vmType){
                found = true;
                result = (*it);
            }
            else
                it++;
        }

    return result;
}


CloudUser* CloudManagerBase::findUser (std::string userType){

    std::vector<CloudUser*>::iterator it;
    CloudUser* result;
    bool found;

        // Init
        found = false;
        result = nullptr;
        it = userTypes.begin();

        // Search...
        while((!found) && (it != userTypes.end())){

            if ((*it)->getType() == userType){
                found = true;
                result = (*it);
            }
            else
                it++;
        }

    return result;
}
