#include "CloudProviderBase.h"

CloudProviderBase::~CloudProviderBase(){

    computingNodeTypes.clear();
    storageNodeTypes.clear();
    computingRackTypes.clear();
    storageRackTypes.clear();
    dataCentersBase.clear();
}


void CloudProviderBase::initialize(){

    int result;
    int numGates, i;

        // Init super-class
        CloudManagerBase::initialize();

            // Get parameters from module
            showDataCenters = par ("showDataCenters");

            // Number of gates
            numGates = gateSize ("fromDataCenter");

            // Init the size of the cGate vectors
            fromDataCenterGates = new cGate* [numGates];
            toDataCenterGates = new cGate* [numGates];

            // Init the cGates vector
            for (i=0; i<numGates; i++){

               // Get cGate object
               fromDataCenterGates [i] = gate ("fromDataCenter", i);
               toDataCenterGates [i] = gate ("toDataCenter", i);

               // Checking connections
               if (!toDataCenterGates[i]->isConnected()){
                   error ("toDataCenterGates %d is not connected", i);
               }
            }

            // Gates to connect the user generator
            fromUserGeneratorGate = gate ("fromUserGenerator");
            toUserGeneratorGate = gate ("toUserGenerator");

            // Parse data-center list
            result = parseDataCentersList();

            // Something goes wrong...
            if (result == SC_ERROR){
                error ("Error while parsing data-centers list");
            }
            else if (showDataCenters){
                EV_DEBUG << dataCentersToString ();
            }
}


cGate* CloudProviderBase::getOutGate (cMessage *msg){

    cGate* outGate;

       // Init...
       outGate = nullptr;

        // If msg arrives from DataCenter
        if (msg->arrivedOn("fromDataCenterGates")){
           outGate = gate ("toDataCenterGates", msg->getArrivalGate()->getIndex());
        }

        // If msg arrives from user generator
        else if (msg->getArrivalGate()==fromUserGeneratorGate){
            outGate = toUserGeneratorGate;
        }

        // Msg arrives from an unknown gate
        else
            error ("Message received from an unknown gate [%s]", msg->getName());

    return outGate;
}


int CloudProviderBase::parseDataCentersList (){

    int numDataCenters, currentDataCenter, result;
    int numComputingRacks, numStorageRacks, currentRack, numRackInstances, currentRackInstance;
    std::string dataCenterNameStr;
    std::string rackName, nodeName;
    int numBoards, bladesPerBoard;
    int disk, numCpus, cpuSpeed;
    double memory;
    DataCenter* dataCenterObj;
    RackInfo* rackInfo;
    NodeInfo* nodeInfo;
    Rack* rack;


        // Init...
        result = SC_OK;
        numDataCenters = currentDataCenter = 0;

        // Read the datacenterList parameter
        const char *dataCentersListChr = par ("dataCentersList");
        cStringTokenizer tokenizer(dataCentersListChr);


        // First token, number of data-centers
        if (tokenizer.hasMoreTokens()){
            const char *numDataCentersChr = tokenizer.nextToken();
            numDataCenters = atoi(numDataCentersChr);
        }
        else{
            EV_ERROR << "Cannot read the first token (number of Data-Centers)" << endl;
            result = SC_ERROR;
        }

        // While there are unprocessed items...
        while ((tokenizer.hasMoreTokens()) && (currentDataCenter < numDataCenters) && (result==SC_OK)){

            // Get the Data-Center name
            if ((tokenizer.hasMoreTokens()) && (result==SC_OK)){
              const char *dataCenterNameChr = tokenizer.nextToken();
              dataCenterNameStr = dataCenterNameChr;
            }
            else{
              EV_ERROR << "Cannot read name of Data-Center:" << currentDataCenter << endl;
              result = SC_ERROR;
            }

            // Create a new Data-Center Info
            if (result==SC_OK){

                // Init...
                currentRack = numComputingRacks = numStorageRacks = 0;

                // Create data-Center object
                dataCenterObj = new DataCenter (dataCenterNameStr);

                // Parse #computingRacks
                if (tokenizer.hasMoreTokens()){
                    const char *numComputingRacksChr = tokenizer.nextToken();
                    numComputingRacks = atoi(numComputingRacksChr);
                }
                else{
                    EV_ERROR << "Cannot read the the number of Computing Racks for data-center:"  << dataCenterNameStr  << endl;
                    result = SC_ERROR;
                }

                // Parse current rack info...
                while ((tokenizer.hasMoreTokens()) && (currentRack < numComputingRacks) && (result==SC_OK)){

                    // Init...
                    numRackInstances = 0;
                    rackInfo = nullptr;
                    nodeInfo = nullptr;

                    // Number of rack instances
                    if (tokenizer.hasMoreTokens() && (result==SC_OK) ){
                        const char *numRackInstancesChr = tokenizer.nextToken();
                        numRackInstances = atoi(numRackInstancesChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the number of instances for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Rack Name
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *rackNameChr = tokenizer.nextToken();
                        rackName = rackNameChr;
                    }
                    else{
                        EV_ERROR << "Cannot read the rack name for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Num boards
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *numBoardsChr = tokenizer.nextToken();
                        numBoards = atoi(numBoardsChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the number of boards for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Blades per board
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *bladesPerBoardChr = tokenizer.nextToken();
                        bladesPerBoard = atoi(bladesPerBoardChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the number of blades per board for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Node Name
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *nodeNameChr = tokenizer.nextToken();
                        nodeName = nodeNameChr;
                    }
                    else{
                        EV_ERROR << "Cannot read the node name for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Disk
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *diskChr = tokenizer.nextToken();
                        disk = atoi(diskChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the Disk for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Memory
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *memoryChr = tokenizer.nextToken();
                        memory = atof(memoryChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the Memory for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // CPU (NumCores)
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *numCpusChr = tokenizer.nextToken();
                        numCpus = atoi(numCpusChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the #Cpus for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // CPU (Speed)
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *cpuSpeedChr = tokenizer.nextToken();
                        cpuSpeed = atoi(cpuSpeedChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the CPU speed for the computing rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Generate Racks and include them in the Data-Center object!

                        // Is the current Rack info already loaded?
                        rackInfo = findRackInfo (rackName, false);
                        nodeInfo = findNodeInfo (nodeName, false);

                        // Rack info not found... create a new one!
                        if (rackInfo == nullptr){

                           // Node info not found... create a new one!
                           if (nodeInfo == nullptr){
                               nodeInfo = new NodeInfo (nodeName, false, disk, memory, numCpus, cpuSpeed);
                           }

                            rackInfo = new RackInfo(rackName, false, numBoards, bladesPerBoard, nodeInfo);
                        }
                        // Check!
                        else if (nodeInfo == nullptr){
                                error ("Node info cannot be nullptr! Error while parsing dataCenter %s - Rack %s - Node %s", dataCenterNameStr.c_str(), rackName.c_str(), nodeName.c_str());
                        }


                        // Create rack instances...
                        for (currentRackInstance = 0; currentRackInstance < numRackInstances; currentRackInstance++){

                            // Create the Rack object
                            rack = new Rack (rackInfo);

                            // Add current rack to the data-center
                            dataCenterObj->addRack(rack, false);
                        }

                    // Process next rack
                    currentRack++;
                }

                // ------------ End of parsing [Computing Racks] ------------

                // Init...
                currentRack = 0;

                // Parse #storageRacks
                if (tokenizer.hasMoreTokens()){
                    const char *numStorageRacksChr = tokenizer.nextToken();
                    numStorageRacks = atoi(numStorageRacksChr);
                }
                else{
                    EV_ERROR << "Cannot read the the number of Storage Racks for data-center:"  << dataCenterNameStr  << endl;
                    result = SC_ERROR;
                }

                // Parse current rack info...
                while ((tokenizer.hasMoreTokens()) && (currentRack < numStorageRacks) && (result==SC_OK)){

                    // Init...
                    numRackInstances = 0;
                    rackInfo = nullptr;
                    nodeInfo = nullptr;

                    // Number of rack instances
                    if (tokenizer.hasMoreTokens() && (result==SC_OK) ){
                        const char *numRackInstancesChr = tokenizer.nextToken();
                        numRackInstances = atoi(numRackInstancesChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the number of instances for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Rack Name
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *rackNameChr = tokenizer.nextToken();
                        rackName = rackNameChr;
                    }
                    else{
                        EV_ERROR << "Cannot read the rack name for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Num boards
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *numBoardsChr = tokenizer.nextToken();
                        numBoards = atoi(numBoardsChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the number of boards for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Blades per board
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *bladesPerBoardChr = tokenizer.nextToken();
                        bladesPerBoard = atoi(bladesPerBoardChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the number of blades per board for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Node Name
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *nodeNameChr = tokenizer.nextToken();
                        nodeName = nodeNameChr;
                    }
                    else{
                        EV_ERROR << "Cannot read the node name for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Disk
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *diskChr = tokenizer.nextToken();
                        disk = atoi(diskChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the Disk for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Memory
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *memoryChr = tokenizer.nextToken();
                        memory = atof(memoryChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the Memory for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // CPU (NumCores)
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *numCpusChr = tokenizer.nextToken();
                        numCpus = atoi(numCpusChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the #Cpus for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // CPU (Speed)
                    if (tokenizer.hasMoreTokens() && (result==SC_OK)){
                        const char *cpuSpeedChr = tokenizer.nextToken();
                        cpuSpeed = atoi(cpuSpeedChr);
                    }
                    else{
                        EV_ERROR << "Cannot read the CPU speed for the storage rack ["  << currentRack  << "]" << endl;
                        result = SC_ERROR;
                    }

                    // Generate Racks and include them in the Data-Center object!

                        // Is the current Rack info already loaded?
                        rackInfo = findRackInfo (rackName, true);
                        nodeInfo = findNodeInfo (nodeName, true);

                        // Rack info not found... create a new one!
                        if (rackInfo == nullptr){

                           // Node info not found... create a new one!
                           if (nodeInfo == nullptr){
                               nodeInfo = new NodeInfo (nodeName, true, disk, memory, numCpus, cpuSpeed);
                           }

                            rackInfo = new RackInfo(rackName, true, numBoards, bladesPerBoard, nodeInfo);
                        }
                        // Check!
                        else if (nodeInfo == nullptr){
                                error ("Node info cannot be nullptr! Error while parsing dataCenter %s - Rack %s - Node %s", dataCenterNameStr.c_str(), rackName.c_str(), nodeName.c_str());
                        }


                        // Create rack instances...
                        for (currentRackInstance = 0; currentRackInstance < numRackInstances; currentRackInstance++){

                            // Create the Rack object
                            rack = new Rack (rackInfo);

                            // Add current rack to the data-center
                            dataCenterObj->addRack(rack, true);
                        }

                    // Process next rack
                    currentRack++;
                }

                // ------------ End of parsing [Storage Racks] ------------
            }

            // Insert the new Data-Center into the vector
            dataCentersBase.push_back(dataCenterObj);

            // Process next data-Center
            currentDataCenter++;
        }

   return result;
}


std::string CloudProviderBase::dataCentersToString (){

    std::ostringstream info;
    int i, currentRack;

        // Main text for the applications of this manager
        info << std::endl << dataCentersBase.size() << " Data-Centers parsed from CloudProviderBase in " << getFullPath() << endl << endl;

        for (i=0; i<dataCentersBase.size(); i++){

            // Name of the data-center
            info << "\tData-Center[" << i << "]  --> " << dataCentersBase.at(i)->getName() << "  -  ";

            // Number of racks
            info << dataCentersBase.at(i)->getNumRacks(false) << " computing racks  -  ";
            info << dataCentersBase.at(i)->getNumRacks(true) << " storage racks" << endl;

            // Features of each rack
            for (currentRack=0; currentRack < dataCentersBase.at(i)->getNumRacks(false); currentRack++){
                info << "\t  + Rack[" << currentRack << "]:" << dataCentersBase.at(i)->getRack(currentRack, false)->getRackInfo()->toString() << endl;
                info << "\t\t - Node config: " << dataCentersBase.at(i)->getRack(currentRack, false)->getRackInfo()->getNodeInfo()->toString() << endl;
            }

            // Features of each rack
            for (currentRack=0; currentRack < dataCentersBase.at(i)->getNumRacks(true); currentRack++){
                info << "\t  + Rack[" << currentRack + dataCentersBase.at(i)->getNumRacks(false) << "]:" << dataCentersBase.at(i)->getRack(currentRack, true)->getRackInfo()->toString() << endl;
                info << "\t\t - Node config: " << dataCentersBase.at(i)->getRack(currentRack, true)->getRackInfo()->getNodeInfo()->toString() << endl;
            }

            info << endl;
        }

        info << "---------------- End of parsed Data-Centers in " << getFullPath() << " ----------------" << endl;

    return info.str();
}


NodeInfo* CloudProviderBase::findNodeInfo (std::string nodeName, bool isStorage){

    std::vector<NodeInfo*>::iterator it;
    std::vector<NodeInfo*>::iterator itEnd;
    NodeInfo* result;
    bool found;

        // Init
        found = false;
        result = nullptr;

        // Set iterators
        if (!isStorage){
            it = computingNodeTypes.begin();
            itEnd = computingNodeTypes.end();
        }
        else{
            it = storageNodeTypes.begin();
            itEnd = storageNodeTypes.end();
        }

            // Search...
            while((!found) && (it != itEnd)){

                if ((*it)->getName() == nodeName){
                    found = true;
                    result = *it;
                }
                else
                    it++;
            }

    return result;
}


RackInfo* CloudProviderBase::findRackInfo (std::string rackName, bool isStorage){

    std::vector<RackInfo*>::iterator it;
    std::vector<RackInfo*>::iterator itEnd;
    RackInfo* result;
    bool found;

        // Init
        found = false;
        result = nullptr;

        // Set iterators
        if (!isStorage){
            it = computingRackTypes.begin();
            itEnd = computingRackTypes.end();
        }
        else{
            it = storageRackTypes.begin();
            itEnd = storageRackTypes.end();
        }

            // Search...
            while((!found) && (it != itEnd)){

                if ((*it)->getName() == rackName){
                    found = true;
                    result = *it;
                }
                else
                    it++;
            }

    return result;
}

