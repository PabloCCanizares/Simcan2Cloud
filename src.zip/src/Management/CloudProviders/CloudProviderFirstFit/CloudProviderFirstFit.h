#ifndef __SIMCAN_2_0_CLOUDPROVIDERFIRSTFIT_H_
#define __SIMCAN_2_0_CLOUDPROVIDERFIRSTFIT_H_

#include "Management/CloudProviders/CloudProviderBase/CloudProviderBase.h"
#include "Management/dataClasses/NodeUserInfo.h"
#include "Management/dataClasses/DataCenterInfoCollection.h"
#include "NodeResourceInfo.h"
#include "Messages/SM_UserVM.h"
#include "Messages/SM_UserAPP.h"
#include "Messages/SM_UserAPP_Finish_m.h"
#include "Messages/SM_CloudProvider_Control_m.h"


/**
 * Class that parses information about the data-centers.
 *
 */
class CloudProviderFirstFit : public CloudProviderBase{

    protected:

        /** Collection of datacenters*/
        DataCenterInfoCollection datacenterCollection;

        /** Map of the accepted users*/
        std::map<std::string, SM_UserVM> acceptedUsersRqMap;

        /** Map of the accepted applications*/
        std::map<std::string, SM_UserAPP*> handlingAppsRqMap;

        /** Queue of the users that are waiting to be handled*/
        std::vector<SM_UserVM*> subscribeQueue;

        /** Flag that indicates if the process has been finished*/
        bool bFinished;

        /** Ni idea*/
        //int nNodeIndex;
        //int nDataCenterIndex;
        // std::vector<int> initialTimes;

        /** Destructor*/
        ~CloudProviderFirstFit();

        /** Initialize the cloud provider*/
        virtual void initialize();

        /**
         * Process a self message.
         * @param msg Self message.
         */
         virtual void processSelfMessage (cMessage *msg);

         /**
         * Process a request message.
         * @param sm Request message.
         */
         virtual void processRequestMessage (SIMCAN_Message *sm);

         /**
         * Process a response message from a module in the local node.
         * @param sm Response message.
         */
         virtual void processResponseMessage (SIMCAN_Message *sm);


         //################################################################
         //API
         /**
          * Handle a user APP request.
          * @param userAPP_Rq User APP request.
          */
         virtual void handleUserAppRequest(SM_UserAPP* userAPP_Rq);

         /** Initializes the structure of each data-center in the cloud */
         virtual void initDataCenterStructures();

         /**
          * Check if the user request fits in the datacenter
          * @param userVM_Rq User request.
          */
         virtual bool checkVmUserFit(SM_UserVM*& userVM_Rq);

         /**
          * Check if the user request fits in the datacenter
          * @param userVM_Rq User request.
          */
         virtual bool checkAppUserFit(SM_UserAPP*& userAPP_Rq);


         /**
          * Update the subscription queue. Analyse the queue in order to find timeouts, and accepting the enqueued VM requests.
          */
         virtual void updateSubsQueue();

         /**
          * Free the resources associated to a VM given its identifier.
          * @param strVmId Identifier of the VM.
          */
         virtual void freeVm(std::string strVmId);

         /**
          * Search a virtual machine per type. This method is used to extract the characteristics necessaries in the fillVmFeatures method.
          * @param strVmType
          * @return
          */
         virtual VirtualMachine* searchVmPerType(std::string strVmType);

         /**
          * Stores a user subscription.
          * @param userVM_Rq VM request.
          */
         virtual void storeVmSubscribe(SM_UserVM* userVM_Rq);

         /**
          * Load the datacenter information
          */
         void loadNodes();


         /**
          * Get the price of a VM given its type.
          * @param strPrice Type of the VM.
          * @return Price of the VM.
          */
         int getPriceByVmType(std::string strPrice);

         /**
          * Free all the VMs associated to an specific user.
          * @param strUsername User to be released.
          */
         virtual void freeUserVms(std::string strUsername);

         /**
          * Fill the VM request features given its type.
          * @param strType VM type.
          * @param pNode Resource request
          */
         void fillVmFeatures(std::string strType, NodeResourceRequest*& pNode);

         /**
          * Insert a new rack in the system.
          * @param nDataCenter Number of datacenter where the rack is inserted.
          * @param nRack Rack number.
          * @param pRackInfo Rack to be inserted.
          */
         void insertRack(int nDataCenter, int nRack, RackInfo* pRackInfo);

         //Auxiliar
         /**
          * Get the total cores of a virtual machine type.
          * @param strVmType Type of the virtual machine.
          * @return Number of cores.
          */
         int getTotalCoresByVmType(std::string strVmType);

         /**
          * Calculate the total cores requested by an specific user.
          * This method is specially useful in order to check if there exist enough space in the datacenter to handle
          * all the requests of the user.
          * @param userVM_Rq User VM request.
          * @return Total number of cores requested by the user.
          */
         int calculateTotalCoresRequested(SM_UserVM* userVM_Rq);

         /**
          * This method is used to calculate the execution time of the applications.
          * Let us remark that it is used in the first stages of the simulation platform, but it will be replaced
          * by a more realistic environment.
          * @param appType
          * @return
          */
         int TEMPORAL_calculateTotalTime(Application* appType);

         //Notifications
         /**
          * Accept the user request.
          * @param userVM_Rq VMs User request.
          */
         void acceptVmRequest(SM_UserVM* userVM_Rq);

         /**
          * Accepts the app request.
          * @param userAPP_Rq apps User submission.
          */
         void acceptAppRequest(SM_UserAPP* userAPP_Rq);

         /**
          *
          * @param userAPP_Rq
          */
         void  acceptAppRequestWithTimeout(SM_UserAPP* userAPP_Rq);

         /**
          * Sends a timeout of VM renting
          * @param userAPP_Rq apps User submission.
          */
         void  timeoutAppRequest(SM_UserAPP* userAPP_Rq);

         /**
          * Rejects the user request.
          * @param userVM_Rq User request.
          */
         void rejectVmRequest(SM_UserVM* userVM_Rq);

         /**
          * Rejects the user application request.
          * @param userAPP_Rq User app submission.
          */
         void rejectAppRequest(SM_UserAPP* userAPP_Rq);

         /**
          * Sends to a subscribed user a notification message.
          * @param userVM_Rq User VM request.
          */
         void notifySubscription(SM_UserVM* userVM_Rq);

         /**
          * Sends a timeout subscription to an specific user.
          * @param userVM_Rq User VM request.
          */
         void timeoutSubscription(SM_UserVM* userVM_Rq);

         void abortAllApps(SM_UserAPP* userApp, std::string strVmId);

         void manageSubscriptionTimeout(cMessage *msg);

         int searchUserInSubQueue(std::string strUsername);
};

#endif
