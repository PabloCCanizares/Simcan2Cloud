#include "NodeUserInfo.h"

NodeUserInfo::NodeUserInfo(){

    userName = "";
    maxStartTime_t1 = 0;
    nRentTime_t2 = 0;
    maxSubTime_t3 = 0;
    maxSubscriptionTime_t4 = 0;
    appRequestMsg = nullptr;
}

NodeUserInfo::~NodeUserInfo() {

}

const std::string& NodeUserInfo::getUserName() const {
    return userName;
}

void NodeUserInfo::setUserName(const std::string& userName) {
    this->userName = userName;
}

const std::string& NodeUserInfo::getVmId() const {
    return vmId;
}

void NodeUserInfo::setVmId(const std::string& vmId) {
    this->vmId = vmId;
}

cMessage* NodeUserInfo::getAppRequestMsg() const {
    return appRequestMsg;
}

void NodeUserInfo::setAppRequestMsg(cMessage* appRequestMsg) {
    this->appRequestMsg = appRequestMsg;
}

int NodeUserInfo::getMaxStartTimeT1() const {
    return maxStartTime_t1;
}

void NodeUserInfo::setMaxStartTimeT1(int maxStartTimeT1) {
    maxStartTime_t1 = maxStartTimeT1;
}

int NodeUserInfo::getRentTimeT2() const {
    return nRentTime_t2;
}

void NodeUserInfo::setRentTimeT2(int rentTimeT2) {
    nRentTime_t2 = rentTimeT2;
}

int NodeUserInfo::getMaxSubTimeT3() const {
    return maxSubTime_t3;
}

void NodeUserInfo::setMaxSubTimeT3(int maxSubTimeT3) {
    maxSubTime_t3 = maxSubTimeT3;
}

int NodeUserInfo::getMaxSubscriptionTimeT4() const {
    return maxSubscriptionTime_t4;
}

void NodeUserInfo::setMaxSubscriptionTimeT4(int maxSubscriptionTimeT4) {
    maxSubscriptionTime_t4 = maxSubscriptionTimeT4;
}






